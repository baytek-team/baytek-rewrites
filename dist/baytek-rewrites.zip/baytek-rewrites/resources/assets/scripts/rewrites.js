jQuery(function($){
    // Trigger the autocompleter
    $('#rewrites-settings .add_select2').select2({
    	placeholder: "Select a page",
    	allowClear: true
    });
});